function changeImage() {
    const currentImage = document.querySelector('#travel_image_1');
    const nextImage = document.querySelector('#travel_image_2');
    const lastImage = document.querySelector('#travel_image_3');
    
    if (currentImage.src === 'travel_image_1.jpg') {
        currentImage.classList.add('hidden');
        nextImage.classList.remove('hidden');
    } else if (currentImage.src === 'travel_image_2.jpg') {
        currentImage.classList.add('hidden');
        lastImage.classList.remove('hidden');
    } else {
        lastImage.classList.add('hidden');
        document.getElementById('travel_image_1').classList.remove('hidden');
    }
}